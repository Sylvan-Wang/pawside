-- =============================================================================
-- AI generation diagnostics
-- =============================================================================
-- Section 0 runs TODAY, before ai_generations exists.
-- Sections 1-9 run once ai_generations is live.
-- All queries are read-only except section 9 (retention, service role only).
-- ASSUMPTION: user_food_logs has (user_id, date); adjust the column name if it
-- is log_date / eaten_at in the real schema.
-- =============================================================================


-- -----------------------------------------------------------------------------
-- 0. Proxy success rate for daily review (no new table needed)
-- -----------------------------------------------------------------------------
-- Only successful composes are written to ai_generated_content, so
--   cached successes / active user-days  ~=  daily review success rate
-- It UNDER-counts when a user never opened Home/History that day, so read it
-- as a lower bound. It cannot split H1 (not running) from H2 (gate rejected).
with active_days as (
  select user_id, date as d from public.workout_logs
  union
  select user_id, date as d from public.user_food_logs          -- ASSUMPTION: column name
),
reviewed as (
  select user_id, target_date as d
  from public.ai_generated_content
  where content_type = 'daily_review_ai'
    and prompt_version = 'openai_daily_review_v3'
)
select
  date_trunc('week', a.d)::date                    as week,
  count(*)                                         as active_user_days,
  count(r.user_id)                                 as with_ai_review,
  round(100.0 * count(r.user_id) / nullif(count(*), 0), 1) as pct_with_ai_review
from active_days a
left join reviewed r on r.user_id = a.user_id and r.d = a.d
where a.d >= current_date - 56
group by 1
order by 1 desc;


-- -----------------------------------------------------------------------------
-- 1. Success rate by surface, last 7 days  (the first number P0-0 must report)
-- -----------------------------------------------------------------------------
select
  surface,
  count(*)                                                        as generations,
  count(*) filter (where status = 'ok')                           as ok,
  round(100.0 * count(*) filter (where status = 'ok') / count(*), 1) as success_pct,
  -- success counting the single feedback retry as one logical request
  round(100.0 * count(distinct coalesce(trace_id::text, id::text)) filter (where status = 'ok')
        / nullif(count(distinct coalesce(trace_id::text, id::text)), 0), 1) as request_success_pct
from public.ai_generations
where created_at >= now() - interval '7 days'
  and invoked_by <> 'eval'
group by surface
order by generations desc;


-- -----------------------------------------------------------------------------
-- 2. Failure reason distribution  (H1 vs H2)
-- -----------------------------------------------------------------------------
-- not_configured / timeout / upstream_error  -> H1 (ops)
-- untraceable_number / unbound_evidence / forbidden_claim / invalid_response -> H2 (output mechanism)
select
  surface,
  fail_reason,
  case
    when fail_reason in ('not_configured', 'timeout', 'upstream_error', 'rate_limited') then 'H1_ops'
    else 'H2_gate'
  end                              as bucket,
  count(*)                         as n,
  round(100.0 * count(*) / sum(count(*)) over (partition by surface), 1) as pct_of_surface_failures
from public.ai_generations
where status = 'failed'
  and created_at >= now() - interval '7 days'
  and invoked_by <> 'eval'
group by surface, fail_reason
order by surface, n desc;


-- -----------------------------------------------------------------------------
-- 3. Which numbers kill outputs  (drives the placeholder-rendering decision)
-- -----------------------------------------------------------------------------
-- fail_detail for untraceable_number is a comma-separated token list.
select
  surface,
  trim(tok)                        as number_token,
  count(*)                         as n
from public.ai_generations,
     lateral unnest(string_to_array(fail_detail, ',')) as tok
where fail_reason = 'untraceable_number'
  and created_at >= now() - interval '14 days'
group by surface, trim(tok)
order by n desc
limit 30;
-- Expectation to check: small integers (1, 2, 3) and day-of-month numbers
-- dominate. If so, placeholder rendering removes most H2 failures.


-- -----------------------------------------------------------------------------
-- 4. Latency and cost by surface
-- -----------------------------------------------------------------------------
select
  surface,
  model,
  percentile_cont(0.5)  within group (order by latency_ms) as p50_ms,
  percentile_cont(0.95) within group (order by latency_ms) as p95_ms,
  round(avg(tokens_in))  as avg_tokens_in,
  round(avg(tokens_out)) as avg_tokens_out
from public.ai_generations
where created_at >= now() - interval '7 days'
  and latency_ms is not null
group by surface, model
order by surface;


-- -----------------------------------------------------------------------------
-- 5. Did the retry help?
-- -----------------------------------------------------------------------------
select
  surface,
  count(*) filter (where attempt = 2)                          as retries,
  count(*) filter (where attempt = 2 and status = 'ok')        as retry_ok,
  round(100.0 * count(*) filter (where attempt = 2 and status = 'ok')
        / nullif(count(*) filter (where attempt = 2), 0), 1)   as retry_success_pct
from public.ai_generations
where created_at >= now() - interval '7 days'
group by surface;


-- -----------------------------------------------------------------------------
-- 6. Join thumbs-down back to the full input  (eval dataset mining)
-- -----------------------------------------------------------------------------
-- ai_feedback carries (prompt_version, model, input_snapshot_id); this table
-- carries the same three plus payload, so a 👎 becomes a replayable case.
select
  f.content_type,
  f.rating,
  g.surface,
  g.prompt_version,
  g.input_snapshot_id,
  g.payload,
  g.output,
  f.created_at
from public.ai_feedback f
join lateral (
  select * from public.ai_generations g
  where g.user_id           = f.user_id
    and g.input_snapshot_id = f.input_snapshot_id
    and g.prompt_version    = f.prompt_version
    and g.status            = 'ok'
  order by g.created_at desc
  limit 1
) g on true
where f.rating = 'disliked'                     -- ASSUMPTION: rating enum value
  and f.created_at >= now() - interval '14 days'
order by f.created_at desc
limit 20;


-- -----------------------------------------------------------------------------
-- 7. Generations that returned but look empty  (H3 proxy)
-- -----------------------------------------------------------------------------
-- Heuristic only: an ok output with zero findings/observations is a candidate
-- for "correct but useless". Review a sample by hand.
select surface, count(*) as ok_but_empty
from public.ai_generations
where status = 'ok'
  and created_at >= now() - interval '7 days'
  and coalesce(jsonb_array_length(output -> 'key_findings'), 0)
    + coalesce(jsonb_array_length(output -> 'observations'), 0) = 0
group by surface;


-- -----------------------------------------------------------------------------
-- 8. Orchestrator trajectories  (reserved: only meaningful once Coach Chat ships)
-- -----------------------------------------------------------------------------
select
  trace_id,
  min(created_at)                                     as started_at,
  count(*)                                            as calls,
  array_agg(surface order by created_at)              as call_sequence,
  bool_and(status = 'ok')                             as all_ok,
  sum(latency_ms)                                     as total_ms
from public.ai_generations
where trace_id is not null
  and invoked_by = 'orchestrator'
  and created_at >= now() - interval '7 days'
group by trace_id
order by started_at desc
limit 50;


-- -----------------------------------------------------------------------------
-- 9. Retention  (service role, schedule daily; 90 days pending review decision)
-- -----------------------------------------------------------------------------
-- delete from public.ai_generations where created_at < now() - interval '90 days';

/**
 * Generation log — writes one row to public.ai_generations per model call,
 * success AND failure.
 *
 * Contract:
 *  - NEVER throws. Logging must not be able to break the facts layer or the
 *    user-facing response (same rule as composeWithEvidence failures).
 *  - Called from exactly one place: composeWithEvidence, right after the gates
 *    decide ok / failed. Surfaces do not call it directly.
 *  - Stores the full payload so the generation can be replayed for eval.
 *
 * ASSUMPTION: a server-side Supabase client factory exists at
 * `@/lib/supabase/server` returning a client bound to the current user.
 * Adjust the import to the repo's actual helper.
 */

import { createClient } from '@/lib/supabase/server' // ASSUMPTION: path

export type AISurface =
  | 'workout_session_feedback'
  | 'meal_feedback'
  | 'daily_review'
  | 'weekly_review'
  | 'advisory_plan'
  | 'coach_chat' // reserved for the future orchestrator

export type AIFailReason =
  | 'not_configured'
  | 'rate_limited'
  | 'timeout'
  | 'upstream_error'
  | 'invalid_response'
  | 'unbound_evidence'
  | 'untraceable_number'
  | 'forbidden_claim'

export type InvokedBy = 'ui' | 'orchestrator' | 'schedule' | 'eval'

/**
 * Tracing context. A surface called from a page passes nothing and gets
 * invoked_by='ui'. The future Coach Chat orchestrator passes one trace_id per
 * user turn so every capability it calls can be stitched into one trajectory.
 */
export interface TraceContext {
  traceId?: string
  parentGenerationId?: string
  invokedBy?: InvokedBy
  turnIndex?: number
}

export interface GenerationRecord {
  userId: string
  surface: AISurface
  scopeId?: string | null
  inputSnapshotId: string
  promptVersion: string
  model: string
  evidenceRegistryVersion?: string | null
  payload: unknown
  output?: unknown | null
  status: 'ok' | 'failed'
  failReason?: AIFailReason | null
  failDetail?: string | null
  attempt?: number
  latencyMs?: number | null
  tokensIn?: number | null
  tokensOut?: number | null
  trace?: TraceContext
}

const MAX_DETAIL_CHARS = 2000

/** Returns the new row id, or null if logging failed (never throws). */
export async function logGeneration(record: GenerationRecord): Promise<string | null> {
  try {
    if (record.status === 'ok' && record.failReason) {
      // Keep the DB consistency constraint from turning into a silent drop.
      record = { ...record, failReason: null, failDetail: null }
    }

    const supabase = await createClient()
    const { data, error } = await supabase
      .from('ai_generations')
      .insert({
        user_id: record.userId,
        surface: record.surface,
        scope_id: record.scopeId ?? null,
        input_snapshot_id: record.inputSnapshotId,
        prompt_version: record.promptVersion,
        model: record.model,
        evidence_registry_version: record.evidenceRegistryVersion ?? null,
        payload: record.payload,
        output: record.output ?? null,
        status: record.status,
        fail_reason: record.failReason ?? null,
        fail_detail: record.failDetail ? record.failDetail.slice(0, MAX_DETAIL_CHARS) : null,
        attempt: record.attempt ?? 1,
        latency_ms: record.latencyMs ?? null,
        tokens_in: record.tokensIn ?? null,
        tokens_out: record.tokensOut ?? null,
        trace_id: record.trace?.traceId ?? null,
        parent_generation_id: record.trace?.parentGenerationId ?? null,
        invoked_by: record.trace?.invokedBy ?? 'ui',
        turn_index: record.trace?.turnIndex ?? null,
      })
      .select('id')
      .single()

    if (error) {
      console.warn('[ai_generations] insert failed', error.code, error.message)
      return null
    }
    return data?.id ?? null
  } catch (err) {
    console.warn('[ai_generations] logging threw', err instanceof Error ? err.message : err)
    return null
  }
}

/*
 * WIRING SKETCH for lib/evidence/composer.ts (not applied — review first)
 * -----------------------------------------------------------------------
 *
 *   const started = Date.now()
 *   const result = await callStructuredOutput(...)          // existing
 *   const gate = runGates(result, facts, signals)           // existing gates + checkForbiddenClaims
 *
 *   await logGeneration({
 *     userId, surface, scopeId,
 *     inputSnapshotId: snapshotId,
 *     promptVersion: AI_PROMPT_VERSIONS[surface],
 *     model: result.model ?? env.OPENAI_MODEL,
 *     evidenceRegistryVersion,
 *     payload: input,                     // the exact object serialised to the provider
 *     output: result.parsed ?? null,
 *     status: gate.ok ? 'ok' : 'failed',
 *     failReason: gate.ok ? null : gate.reason,
 *     failDetail: gate.ok ? null : gate.detail,
 *     attempt,
 *     latencyMs: Date.now() - started,
 *     tokensIn: result.usage?.input_tokens ?? null,   // ASSUMPTION: surface usage from ai-client
 *     tokensOut: result.usage?.output_tokens ?? null,
 *     trace,                              // new optional composeWithEvidence param
 *   })
 *
 * Note: failures that happen BEFORE a model call (unbound_evidence is decided
 * pre-spend) are still logged, with output=null and latency of the gate only.
 */

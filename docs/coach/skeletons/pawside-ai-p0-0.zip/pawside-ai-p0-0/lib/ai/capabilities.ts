/**
 * Capability contract — the reserved slot for the future Coach Chat.
 *
 * Every AI surface today (daily review, workout feedback, meal feedback,
 * weekly review) is a CAPABILITY: fixed input, schema-bound output, single
 * model call, no autonomous next step. That is what makes them controllable,
 * and it should stay that way.
 *
 * The future Coach Chat is the ONE agent: it decides which capabilities to
 * call. It does so through this registry, which converts directly into tool
 * definitions. Nothing here calls a model; it is declaration only.
 *
 * Rules the orchestrator inherits by construction:
 *   1. Capabilities are read-only (sideEffect: 'none').
 *   2. The only write path is create_proposal (sideEffect: 'proposal'), which
 *      produces a PENDING Action Proposal. Applying it still requires user
 *      confirmation + a deterministic policy validator.
 *   3. Every capability call is logged to ai_generations with the chat turn's
 *      trace_id and invoked_by='orchestrator'.
 *   4. The orchestrator's own reply passes the same output checks
 *      (placeholders, forbidden claims). It is not a new ungated exit.
 *
 * Adding a surface = adding one entry here. A surface without an entry cannot
 * be reached from chat.
 *
 * ASSUMPTION: zod is available (the audit shows zod validation in routes).
 */

import { z } from 'zod'
import type { AISurface } from './generation-log'

export type SideEffect = 'none' | 'proposal'

export interface CapabilityDefinition<I extends z.ZodTypeAny = z.ZodTypeAny> {
  /** Tool name exposed to the orchestrator. snake_case, stable. */
  name: string
  /** One sentence the orchestrator reads to decide when to call it. */
  description: string
  input: I
  /** Name of the strict output schema in AI_SCHEMAS, or 'deterministic'. */
  outputSchema: string | 'deterministic'
  sideEffect: SideEffect
  /** Surface for logging; null for purely deterministic tools. */
  surface: AISurface | null
  /** Prompt version key in AI_PROMPT_VERSIONS; null when no model is called. */
  promptVersionKey: string | null
  /** Status of the underlying implementation today. */
  status: 'LIVE' | 'BACKEND_READY' | 'PLANNED'
}

const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/)

export const CAPABILITIES = [
  {
    name: 'get_state_snapshot',
    description: '读取用户当前的长期状态：目标、Method、cycle、近期训练、营养、恢复、身体趋势、数据完整度。回答任何问题前先调用。',
    input: z.object({}),
    outputSchema: 'deterministic',
    sideEffect: 'none',
    surface: null,
    promptVersionKey: null,
    status: 'PLANNED', // Coach State Snapshot, P1
  },
  {
    name: 'get_daily_review',
    description: '获取某一天的复盘：关键发现、明天建议、数据质量提示。',
    input: z.object({ date }),
    outputSchema: 'dailyReviewSchemaV2',
    sideEffect: 'none',
    surface: 'daily_review',
    promptVersionKey: 'daily_review',
    status: 'LIVE',
  },
  {
    name: 'get_session_review',
    description: '获取某次训练的复盘：完成情况、值得关注的变化、下一次建议。',
    input: z.object({ workout_log_id: z.string().uuid() }),
    outputSchema: 'workoutSessionFeedbackSchema', // ASSUMPTION: schema key name
    sideEffect: 'none',
    surface: 'workout_session_feedback',
    promptVersionKey: 'workout_session_feedback',
    status: 'LIVE',
  },
  {
    name: 'get_meal_feedback',
    description: '获取某天饮食的累计、目标、剩余与下一餐方向。',
    input: z.object({ date }),
    outputSchema: 'mealFeedbackSchema', // ASSUMPTION
    sideEffect: 'none',
    surface: 'meal_feedback',
    promptVersionKey: 'meal_feedback',
    status: 'LIVE',
  },
  {
    name: 'get_weekly_review',
    description: '获取某一周的模式、亮点与下周重点。',
    input: z.object({ week_start: date }),
    outputSchema: 'weeklyReviewSchema', // ASSUMPTION
    sideEffect: 'none',
    surface: 'weekly_review',
    promptVersionKey: 'weekly_review',
    status: 'BACKEND_READY',
  },
  {
    name: 'explain_signal',
    description: '解释某条判断为什么成立：依据的数据、证据来源、证据等级；数据不足时说明为什么无法判断。',
    input: z.object({ metric_key: z.string(), date: date.optional() }),
    outputSchema: 'deterministic', // Evidence Registry + resolveCitations, no model
    sideEffect: 'none',
    surface: null,
    promptVersionKey: null,
    status: 'BACKEND_READY',
  },
  {
    name: 'list_proposal_candidates',
    description: '列出规则层为下一次训练生成的合法调整候选（如缩到 45 分钟、减少 accessory、defer）。',
    input: z.object({ target: z.enum(['next_session']), reason: z.string().max(200).optional() }),
    outputSchema: 'deterministic', // policy engine, P1
    sideEffect: 'none',
    surface: null,
    promptVersionKey: null,
    status: 'PLANNED',
  },
  {
    name: 'create_proposal',
    description: '从候选中选一个，生成待用户确认的调整。不会直接修改处方。',
    input: z.object({
      candidate_id: z.string(),          // MUST come from list_proposal_candidates
      rationale: z.string().max(240),    // placeholders only, no bare numbers
    }),
    outputSchema: 'deterministic',
    sideEffect: 'proposal',
    surface: null,
    promptVersionKey: null,
    status: 'PLANNED',
  },
  {
    name: 'parse_food_text',
    description: '把一句自然语言饮食描述解析成候选食物与份量，交给用户确认；营养数值由确定性计算得出。',
    input: z.object({ text: z.string().min(1).max(500), date }),
    outputSchema: 'foodParseSchema', // PLANNED; may become its own sub-agent (multi-step lookup + clarify)
    sideEffect: 'none',              // returns a draft; saving is a separate confirmed user action
    surface: null,                   // add 'nl_food_parse' to the surface check when built
    promptVersionKey: null,
    status: 'PLANNED',
  },
] as const satisfies readonly CapabilityDefinition[]

export type CapabilityName = (typeof CAPABILITIES)[number]['name']

/** Only LIVE / BACKEND_READY capabilities are offered to the orchestrator. */
export function availableCapabilities() {
  return CAPABILITIES.filter(c => c.status !== 'PLANNED')
}

/**
 * Invariant check — run in CI. Guarantees the orchestrator has exactly one
 * write path and that it cannot be reached without a candidate id.
 */
export function assertCapabilityInvariants(): void {
  const writers = CAPABILITIES.filter(c => c.sideEffect !== 'none')
  if (writers.length !== 1 || writers[0].name !== 'create_proposal') {
    throw new Error('Exactly one capability may have side effects: create_proposal')
  }
  const names = new Set<string>()
  for (const c of CAPABILITIES) {
    if (names.has(c.name)) throw new Error(`Duplicate capability: ${c.name}`)
    names.add(c.name)
  }
}

/*
 * Converting to tool definitions (sketch, provider-agnostic):
 *
 *   availableCapabilities().map(c => ({
 *     name: c.name,
 *     description: c.description,
 *     input_schema: zodToJsonSchema(c.input),
 *   }))
 */

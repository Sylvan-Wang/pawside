/**
 * Deterministic output checks.
 *
 * ONE implementation shared by:
 *   - the runtime gate in composeWithEvidence (reject before the user sees it)
 *   - the offline eval (tests/ai-eval, scripts/ai-eval.mts)
 * so "what CI checks" and "what production enforces" cannot drift. The audit
 * already found two diverging numeric-integrity implementations; this file is
 * meant to become the single one (retire validateNumericIntegrity /
 * findUntraceableNumbers once composer uses it).
 *
 * Pure functions, no I/O, no provider calls.
 *
 * ASSUMPTION: MetricFact / InterpretedSignal shapes below are the minimal
 * subset of lib/nutrition/interpretation.ts that these checks need.
 */

export interface FactLike {
  metric_key: string
  value: number | null
  unit?: string | null
}

export interface SignalLike {
  metric_key: string
  status: string
  evidence_ref_ids: string[]
}

export interface RegistryLike {
  /** evidence_id -> forbidden claim strings */
  forbiddenClaims: Map<string, string[]>
  /** all known evidence ids */
  ids: Set<string>
  /** claims forbidden regardless of evidence id (product-wide guardrails) */
  globalForbidden?: string[]
}

export type CheckFailure =
  | { code: 'unresolved_placeholder'; detail: string[] }
  | { code: 'bare_number'; detail: string[] }
  | { code: 'forbidden_claim'; detail: string[] }
  | { code: 'unknown_evidence_id'; detail: string[] }
  | { code: 'status_escalated'; detail: string[] }

export interface CheckResult {
  ok: boolean
  failures: CheckFailure[]
}

/* ------------------------------------------------------------------------- */
/* User-facing string collection                                              */
/* ------------------------------------------------------------------------- */

/** Machine fields whose strings are never shown to the user (mirrors composer). */
const MACHINE_KEYS = new Set([
  'evidence_ref_ids', 'signal_key', 'metric_key', 'status',
  'domain', 'basis', 'direction', 'level', 'chosen_proposal_id',
])

export function collectUserFacingStrings(value: unknown, out: string[] = []): string[] {
  if (typeof value === 'string') {
    out.push(value)
  } else if (Array.isArray(value)) {
    for (const v of value) collectUserFacingStrings(v, out)
  } else if (value && typeof value === 'object') {
    for (const [k, v] of Object.entries(value)) {
      if (!MACHINE_KEYS.has(k)) collectUserFacingStrings(v, out)
    }
  }
  return out
}

/* ------------------------------------------------------------------------- */
/* 1. Placeholder rendering (replaces the free-number gate)                    */
/* ------------------------------------------------------------------------- */
/*
 * The model writes {{metric_key}} instead of digits. The server substitutes
 * the fact value + unit. Numbers can therefore only come from facts.
 *
 *   "今天蛋白还差 {{nutrition.protein_remaining}}"  ->  "今天蛋白还差 42 g"
 */

const PLACEHOLDER = /\{\{\s*([a-z0-9_.]+)\s*\}\}/gi

export function formatFact(f: FactLike): string {
  if (f.value === null || !Number.isFinite(f.value)) return ''
  const v = Number.isInteger(f.value) ? String(f.value) : String(Math.round(f.value * 10) / 10)
  return f.unit ? `${v} ${f.unit}` : v
}

export function renderPlaceholders(
  text: string,
  facts: FactLike[],
): { text: string; unresolved: string[] } {
  const byKey = new Map(facts.map(f => [f.metric_key, f]))
  const unresolved: string[] = []
  const rendered = text.replace(PLACEHOLDER, (_m, key: string) => {
    const fact = byKey.get(key)
    const formatted = fact ? formatFact(fact) : ''
    if (!formatted) {
      unresolved.push(key)
      return ''
    }
    return formatted
  })
  return { text: rendered, unresolved }
}

/** Deep-render every user-facing string in a model output object. */
export function renderOutput<T>(output: T, facts: FactLike[]): { output: T; unresolved: string[] } {
  const unresolved: string[] = []
  const walk = (v: unknown, key?: string): unknown => {
    if (typeof v === 'string') {
      if (key && MACHINE_KEYS.has(key)) return v
      const r = renderPlaceholders(v, facts)
      unresolved.push(...r.unresolved)
      return r.text
    }
    if (Array.isArray(v)) return v.map(x => walk(x, key))
    if (v && typeof v === 'object') {
      return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, walk(x, k)]))
    }
    return v
  }
  return { output: walk(output) as T, unresolved }
}

/**
 * Before rendering: the raw model output must contain NO bare digits in
 * user-facing text. Digits inside {{...}} are keys, not numbers, and are
 * stripped before scanning. Fullwidth digits are normalised first.
 */
export function findBareNumbers(rawOutput: unknown): string[] {
  const hits: string[] = []
  for (const s of collectUserFacingStrings(rawOutput)) {
    const stripped = s
      .replace(PLACEHOLDER, '')
      .replace(/[０-９]/g, d => String.fromCharCode(d.charCodeAt(0) - 0xfee0))
    const m = stripped.match(/\d+(?:\.\d+)?/g)
    if (m) hits.push(...m)
  }
  return hits
}

/* ------------------------------------------------------------------------- */
/* 2. Forbidden claims (registry forbidden_claims enforced on output)          */
/* ------------------------------------------------------------------------- */

const normalise = (s: string) => s.replace(/\s+/g, '').toLowerCase()

/** "官方规定你必须吃 XXg" -> matches "官方规定你必须吃120g" as well. */
const NUM_SENTINEL = '\u0000'
function claimToRegex(claim: string): RegExp {
  // Only UPPERCASE X / XX / XXX are wildcards; lowercase x in English words
  // ("exact") must stay literal. Mark them before lowercasing.
  const marked = claim.replace(/X{1,3}/g, NUM_SENTINEL)
  const escaped = normalise(marked).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return new RegExp(escaped.split(NUM_SENTINEL).join('\\d+(?:\\.\\d+)?'))
}

/**
 * Checks against claims of the evidence ids actually in play (signals sent to
 * the model) plus product-wide guardrails. Deliberately NOT all claims in the
 * registry: "训练量不足" is forbidden for one evidence entry but could be a
 * legitimate phrase elsewhere.
 */
export function findForbiddenClaims(
  renderedOutput: unknown,
  signals: SignalLike[],
  registry: RegistryLike,
): string[] {
  const claims = new Set<string>(registry.globalForbidden ?? [])
  for (const s of signals) {
    for (const id of s.evidence_ref_ids) {
      for (const c of registry.forbiddenClaims.get(id) ?? []) claims.add(c)
    }
  }
  const text = normalise(collectUserFacingStrings(renderedOutput).join('\n'))
  return [...claims].filter(c => claimToRegex(c).test(text))
}

/* ------------------------------------------------------------------------- */
/* 3. Evidence ids in the output must exist and must have been supplied        */
/* ------------------------------------------------------------------------- */

export function findUnknownEvidenceIds(
  output: unknown,
  signals: SignalLike[],
  registry: RegistryLike,
): string[] {
  const supplied = new Set(signals.flatMap(s => s.evidence_ref_ids))
  const bad: string[] = []
  const walk = (v: unknown, key?: string) => {
    if (key === 'evidence_ref_ids' && Array.isArray(v)) {
      for (const id of v) {
        if (typeof id !== 'string' || !registry.ids.has(id) || !supplied.has(id)) bad.push(String(id))
      }
      return
    }
    if (Array.isArray(v)) v.forEach(x => walk(x, key))
    else if (v && typeof v === 'object') Object.entries(v).forEach(([k, x]) => walk(x, k))
  }
  walk(output)
  return bad
}

/* ------------------------------------------------------------------------- */
/* 4. The model may not make a judgement stronger than the rule did           */
/* ------------------------------------------------------------------------- */

const NON_JUDGEMENT = new Set(['not_assessable', 'insufficient_data'])
const RANK: Record<string, number> = {
  within_reference: 0,
  ok: 0,
  info: 0,
  below_reference: 1,
  above_reference: 1,
  caution: 2,
  warning: 3,
}

interface ObservationLike { signal_key?: string; status?: string }

export function findEscalatedStatuses(output: unknown, signals: SignalLike[]): string[] {
  const bySignal = new Map(signals.map(s => [s.metric_key, s.status]))
  const obs: ObservationLike[] =
    (output as { observations?: ObservationLike[] })?.observations ?? []
  const bad: string[] = []
  for (const o of obs) {
    if (!o.signal_key || !o.status) continue
    const input = bySignal.get(o.signal_key)
    if (input === undefined) {
      bad.push(`${o.signal_key}:not_supplied`)
    } else if (NON_JUDGEMENT.has(input)) {
      if (o.status !== input) bad.push(`${o.signal_key}:${input}->${o.status}`)
    } else if ((RANK[o.status] ?? 99) > (RANK[input] ?? -1)) {
      bad.push(`${o.signal_key}:${input}->${o.status}`)
    }
  }
  return bad
}

/* ------------------------------------------------------------------------- */
/* Aggregate                                                                   */
/* ------------------------------------------------------------------------- */

export interface RunChecksInput {
  rawOutput: unknown
  facts: FactLike[]
  signals: SignalLike[]
  registry: RegistryLike
  /** false while a surface still uses free numbers (pre-v4 prompts) */
  placeholderMode: boolean
}

export function runOutputChecks(input: RunChecksInput): CheckResult & { rendered: unknown } {
  const failures: CheckFailure[] = []
  let rendered: unknown = input.rawOutput

  if (input.placeholderMode) {
    const bare = findBareNumbers(input.rawOutput)
    if (bare.length) failures.push({ code: 'bare_number', detail: bare })
    const r = renderOutput(input.rawOutput, input.facts)
    rendered = r.output
    if (r.unresolved.length) failures.push({ code: 'unresolved_placeholder', detail: r.unresolved })
  }

  const forbidden = findForbiddenClaims(rendered, input.signals, input.registry)
  if (forbidden.length) failures.push({ code: 'forbidden_claim', detail: forbidden })

  const unknownIds = findUnknownEvidenceIds(input.rawOutput, input.signals, input.registry)
  if (unknownIds.length) failures.push({ code: 'unknown_evidence_id', detail: unknownIds })

  const escalated = findEscalatedStatuses(input.rawOutput, input.signals)
  if (escalated.length) failures.push({ code: 'status_escalated', detail: escalated })

  return { ok: failures.length === 0, failures, rendered }
}

/**
 * Feedback text for the single retry proposed in P0-0. Appended to the
 * instructions on attempt 2; never shown to the user.
 */
export function retryHint(failures: CheckFailure[]): string {
  return failures
    .map(f => {
      switch (f.code) {
        case 'bare_number': return `不要写数字 ${f.detail.join('、')}；数字只能用 {{metric_key}} 占位符。`
        case 'unresolved_placeholder': return `占位符 ${f.detail.join('、')} 不存在，只能使用 facts 中的 metric_key。`
        case 'forbidden_claim': return `不要使用以下表述：${f.detail.join('；')}。`
        case 'unknown_evidence_id': return `evidence_ref_ids 只能来自输入信号：去掉 ${f.detail.join('、')}。`
        case 'status_escalated': return `observation 的 status 不得强于输入信号：${f.detail.join('、')}。`
      }
    })
    .join('\n')
}

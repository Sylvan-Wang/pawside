/**
 * Adapter: evidence-registry.json -> RegistryLike used by output-checks.
 * Reads the JSON directly so the eval does not depend on registry.ts internals.
 * In composer, build the same object once at module load from registry.ts.
 *
 * ASSUMPTION: the registry file is an object with `entries: [{ evidence_id,
 * forbidden_claims: string[] }]`. Adjust the two field names if different.
 */

import { readFileSync } from 'node:fs'
import type { RegistryLike } from '../lib/evidence/output-checks'

const REGISTRY_PATH = 'docs/product/evidence/evidence-registry.json'

/**
 * Product-wide guardrails, independent of which evidence is in play.
 * Substring match, no negation handling: keep phrases that are wrong even in a
 * disclaimer ("这不是过度训练" is still a training-state claim).
 */
const GLOBAL_FORBIDDEN = ['过度训练', '你患有']

export function loadRegistryForChecks(): RegistryLike {
  const raw = JSON.parse(readFileSync(REGISTRY_PATH, 'utf8')) as
    { entries?: Array<{ evidence_id: string; forbidden_claims?: string[] }> }
  const entries = raw.entries ?? []
  return {
    ids: new Set(entries.map(e => e.evidence_id)),
    forbiddenClaims: new Map(entries.map(e => [e.evidence_id, e.forbidden_claims ?? []])),
    globalForbidden: GLOBAL_FORBIDDEN,
  }
}

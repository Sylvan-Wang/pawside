/**
 * Offline eval — real provider calls over the golden set.
 *
 *   npm run ai:eval                      # run + compare with baseline
 *   npm run ai:eval -- --update-baseline # accept current scores as baseline
 *   npm run ai:eval -- --no-judge        # deterministic layer only (cheap)
 *
 * Run it BEFORE bumping any AI_PROMPT_VERSIONS entry or changing OPENAI_MODEL.
 * Regression rule (see review doc): deterministic pass rate must not drop,
 * and mean judge score must not drop by more than 0.2.
 *
 * Needs the same env as the app (OPENAI_API_KEY, proxy via
 * scripts/run-next-with-proxy.mjs conventions). Generations are tagged
 * invoked_by='eval' if logging is enabled, so they never pollute diagnostics.
 *
 * ASSUMPTIONS: composeWithEvidence signature as in the integration test;
 * callStructuredOutput can be used directly for the judge with an ad-hoc schema.
 */

import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { composeWithEvidence } from '../lib/evidence/composer'
import { callStructuredOutput } from '../lib/ai-client'
import { AI_PROMPT_VERSIONS } from '../lib/evidence/ai-schemas'
import { collectUserFacingStrings, findEscalatedStatuses, findForbiddenClaims, type RegistryLike } from '../lib/evidence/output-checks'
import { loadRegistryForChecks } from './eval-registry' // ASSUMPTION: thin adapter over lib/evidence/registry.ts
import { SEED_CASES, type EvalCase } from '../tests/ai-eval/cases'

const BASELINE = 'tests/ai-eval/baseline.json'
const args = new Set(process.argv.slice(2))
const useJudge = !args.has('--no-judge')

interface CaseResult {
  id: string
  ok: boolean
  failReason?: string
  deterministic: { passed: boolean; problems: string[] }
  judge?: { specificity: number; groundedness: number; actionability: number; tone: number; comment: string }
}

/* ---------- deterministic layer: case expectations on top of runtime checks ---------- */

function checkExpectations(c: EvalCase, output: Record<string, unknown>, registry: RegistryLike): string[] {
  const problems: string[] = []
  const items = [
    ...((output.key_findings as unknown[]) ?? []),
    ...((output.observations as unknown[]) ?? []),
  ] as Array<{ signal_key?: string; status?: string }>

  if (c.expect.maxFindings !== undefined && items.length > c.expect.maxFindings) {
    problems.push(`too_many_findings:${items.length}>${c.expect.maxFindings}`)
  }
  if (c.expect.mustMention?.length) {
    const text = JSON.stringify(output)
    if (!c.expect.mustMention.some(k => text.includes(k) || items.some(i => i.signal_key === k))) {
      problems.push(`missing_mention:${c.expect.mustMention.join('|')}`)
    }
  }
  if (c.expect.mustStayNotAssessable?.length) {
    for (const k of c.expect.mustStayNotAssessable) {
      const o = items.find(i => i.signal_key === k)
      if (o && o.status !== 'not_assessable' && o.status !== 'insufficient_data') problems.push(`judged_unassessable:${k}`)
    }
  }
  if (c.expect.expectsDataQualityTip && !output.data_quality_tip) problems.push('missing_data_quality_tip')

  problems.push(...findEscalatedStatuses(output, c.signals).map(p => `escalated:${p}`))
  problems.push(...findForbiddenClaims(output, c.signals, registry).map(p => `forbidden:${p}`))
  return problems
}

/* ---------- LLM judge layer ---------- */

const JUDGE_SCHEMA = {
  name: 'pawside_eval_judge_v1',
  schema: {
    type: 'object', additionalProperties: false,
    properties: {
      specificity:   { type: 'integer', minimum: 1, maximum: 5 },
      groundedness:  { type: 'integer', minimum: 1, maximum: 5 },
      actionability: { type: 'integer', minimum: 1, maximum: 5 },
      tone:          { type: 'integer', minimum: 1, maximum: 5 },
      comment:       { type: 'string', maxLength: 200 },
    },
    required: ['specificity', 'groundedness', 'actionability', 'tone', 'comment'],
  },
}

const JUDGE_RUBRIC = `你在评估一个健身 App 的 AI 反馈。只依据给出的输入与输出打分，1–5 分：
- specificity 具体性：是否提到这个用户的具体事实，而不是任何人都适用的话（5=每句都指向输入中的具体数据）
- groundedness 扎根性：每个说法能否从输入推出；出现输入里没有的判断即 ≤2
- actionability 可行动性：下一步是否能直接执行（5=明确做什么、何时）；数据不足时，诚实说明并建议补记录也算可行动
- tone 语气：简洁、工具型、不说教、不营销、不过度鼓励
comment 用一句话写出最主要的扣分原因。`

async function judge(c: EvalCase, output: unknown) {
  const res = await callStructuredOutput({
    schema: JUDGE_SCHEMA,
    instructions: JUDGE_RUBRIC,
    input: JSON.stringify({ case_note: c.note, facts: c.facts, signals: c.signals, context: c.context, output: collectUserFacingStrings(output) }),
    maxOutputTokens: 300,
  } as never) as { ok: boolean; data?: CaseResult['judge'] }
  return res.ok ? res.data : undefined
}

/* ---------- run ---------- */

async function main() {
  const registry = loadRegistryForChecks()
  const results: CaseResult[] = []

  for (const c of SEED_CASES) {
    const r = await composeWithEvidence({
      surface: c.surface, facts: c.facts, signals: c.signals, context: c.context,
      trace: { invokedBy: 'eval' },
    } as never) as { ok: boolean; output?: Record<string, unknown>; reason?: string }

    if (!r.ok || !r.output) {
      results.push({ id: c.id, ok: false, failReason: r.reason, deterministic: { passed: false, problems: [`compose_failed:${r.reason}`] } })
      console.log(`✗ ${c.id}  compose failed: ${r.reason}`)
      continue
    }
    const problems = checkExpectations(c, r.output, registry)
    const result: CaseResult = { id: c.id, ok: true, deterministic: { passed: problems.length === 0, problems } }
    if (useJudge) result.judge = await judge(c, r.output)
    results.push(result)
    console.log(`${problems.length ? '✗' : '✓'} ${c.id}  ${problems.join(', ')}${result.judge ? `  judge=${mean(result.judge).toFixed(2)}` : ''}`)
  }

  const summary = {
    prompt_versions: AI_PROMPT_VERSIONS,
    model: process.env.OPENAI_MODEL ?? 'default',
    compose_success: rate(results.map(r => r.ok)),
    deterministic_pass: rate(results.map(r => r.deterministic.passed)),
    judge_mean: useJudge ? avg(results.flatMap(r => (r.judge ? [mean(r.judge)] : []))) : null,
    results,
  }
  console.log(`\ncompose ${pct(summary.compose_success)}  deterministic ${pct(summary.deterministic_pass)}  judge ${summary.judge_mean?.toFixed(2) ?? '—'}`)

  if (args.has('--update-baseline')) {
    writeFileSync(BASELINE, JSON.stringify(summary, null, 2))
    console.log(`baseline written to ${BASELINE}`)
    return
  }
  if (existsSync(BASELINE)) {
    const base = JSON.parse(readFileSync(BASELINE, 'utf8'))
    const regressions: string[] = []
    if (summary.deterministic_pass < base.deterministic_pass) regressions.push(`deterministic ${pct(base.deterministic_pass)} → ${pct(summary.deterministic_pass)}`)
    if (summary.judge_mean !== null && base.judge_mean !== null && summary.judge_mean < base.judge_mean - 0.2) {
      regressions.push(`judge ${base.judge_mean.toFixed(2)} → ${summary.judge_mean.toFixed(2)}`)
    }
    if (regressions.length) {
      console.error(`\nREGRESSION vs baseline:\n  ${regressions.join('\n  ')}`)
      process.exit(1)
    }
    console.log('no regression vs baseline')
  }
}

const mean = (j: NonNullable<CaseResult['judge']>) => (j.specificity + j.groundedness + j.actionability + j.tone) / 4
const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null)
const rate = (xs: boolean[]) => (xs.length ? xs.filter(Boolean).length / xs.length : 0)
const pct = (x: number) => `${Math.round(x * 100)}%`

main().catch(err => { console.error(err); process.exit(1) })

# Pawside P0-0：AI 可观测性与评估 — 配套代码

配合评审文档《Pawside AI 工程补充评审：可观测性、评估与编排预留》使用。所有文件都是**骨架**：标了 `ASSUMPTION` 的地方需要对照仓库确认函数签名或字段名。

## 背景（一段话）

现在的 AI 只在成功时落库，失败没有痕迹；`input_snapshot_id` 是哈希，拿到一条 👎 也回放不了；没有任何测试调用过 `composeWithEvidence`。所以当用户说"AI 不明显"时，我们分不清是 AI 没跑、被闸门拒了、说了空话，还是被 UI 藏了。这套代码的目的是先让这四种情况**可测**，再决定改什么。

## 文件与作用

| 文件 | 作用 | 何时用 |
| --- | --- | --- |
| `supabase/migrations/20260926000400_ai_generations.sql` | 生成日志表，成功失败都写，存完整 payload；预留 Chat 编排层的 `trace_id` / `parent_generation_id` / `invoked_by` / `turn_index` 和 `coach_chat` surface | 第 1 步 |
| `supabase/diagnostics/ai_generation_diagnostics.sql` | 第 0 节**今天就能跑**（无需新表）；1–8 节在表上线后看成功率、失败原因、耗时、👎 回放、编排轨迹 | 第 0 步 / 每周 |
| `lib/ai/generation-log.ts` | `logGeneration()`，永不抛错；文件底部是 composer 接入示意 | 第 2 步 |
| `lib/evidence/output-checks.ts` | 占位符渲染、裸数字检查、`forbidden_claims`、证据 id、判断不得升级；外加重试提示 `retryHint()` | 第 3 步 |
| `lib/ai/capabilities.ts` | 能力契约：未来 Coach Chat 的工具清单；CI 断言"只有 `create_proposal` 一个写入口" | 现在就遵守 |
| `tests/ai-eval/cases.ts` | 8 个种子用例（空白日、只练不吃、当天未结束、恢复很低……） | 扩到 30–50 条 |
| `tests/ai-eval/output-checks.test.ts` | 检查器单测 + 能力契约不变量 | 每次 CI |
| `tests/ai-eval/composer.integration.test.ts` | composer 七个分支，fetch 打桩，不需要网络 | 每次 CI |
| `scripts/ai-eval.mts` + `scripts/eval-registry.ts` | 真实调用 + 用例期望 + LLM 评审 + 基线对比 | 改 prompt / 换模型前 |

## 接入步骤

0. **先跑诊断第 0 节**，得到 daily review 成功率的下限。低于 80%，P0 先修闸门和配置。
1. 应用 migration。
2. 在 `composeWithEvidence` 里接 `logGeneration()`（见 `generation-log.ts` 底部），并给它加一个可选参数 `trace?: TraceContext`。
3. 把 `findForbiddenClaims` 接进 composer 的闸门，失败原因记为 `forbidden_claim`。
4. 失败时用 `retryHint()` 重试一次，`attempt=2`。
5. 新 prompt 版本（如 `openai_daily_review_v4`）改为占位符输出，打开 `placeholderMode`。旧版本保持不变，便于 A/B。
6. `package.json` 增加：
   ```json
   "ai:eval": "node --env-file=.env.local --import tsx scripts/ai-eval.mts"
   ```
   首次运行加 `--update-baseline`。

## 为 Chat 编排层预留了什么

- **日志**：一次对话里调用的所有能力共享一个 `trace_id`，`invoked_by='orchestrator'`，诊断第 8 节可直接看调用序列。
- **能力契约**：`CAPABILITIES` 就是编排 agent 的工具清单；没有声明的 surface，Chat 调用不到。
- **读写分离**：能力全部只读，唯一的写入口是 `create_proposal`，它只能引用规则层给出的候选，生成待确认的调整。
- **同一套闸门**：Chat 的回答也要经过 `runOutputChecks`，不是新开的一个没有闸门的出口。
- **eval 分两级**：先做能力级（本目录），Chat 上线时再加轨迹级（调用了哪些工具、回答是否扎根于工具结果）。

## 已知限制

- `forbidden_claims` 用的是去空格后的子串匹配，不理解否定句。所以全局禁用词只保留那些放在免责句里也不该出现的说法。
- 诊断第 0 节是下限估计：用户当天没打开 Home 或 History，也会被算成"没有复盘"。
- `input_snapshot_id` 相同但 prompt 版本不同的两条记录，都保存在 `ai_generations` 里；与 👎 关联时要带上 `prompt_version` 一起匹配（诊断第 6 节已经这么做）。

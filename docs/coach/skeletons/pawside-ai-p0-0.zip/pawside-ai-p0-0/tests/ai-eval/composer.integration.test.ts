/**
 * composeWithEvidence integration tests — the seven branches the audit found
 * completely untested. No network: global fetch is stubbed.
 *
 * ASSUMPTIONS to confirm against lib/evidence/composer.ts:
 *   - signature: composeWithEvidence({ surface, facts, signals, context })
 *   - result:    { ok: true, output, ... } | { ok: false, reason, detail }
 *   - ai-client reads process.env.OPENAI_API_KEY at call time
 * If the signature differs, change only `compose()` below.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { composeWithEvidence } from '../../lib/evidence/composer'

type Reply = { status: number; body?: unknown } | 'timeout'

function stubFetch(reply: Reply) {
  vi.stubGlobal('fetch', vi.fn(async (_url: string, init?: RequestInit) => {
    if (reply === 'timeout') {
      // Honour the AbortSignal the client passes, like a real hung socket.
      return new Promise((_resolve, reject) => {
        init?.signal?.addEventListener('abort', () =>
          reject(Object.assign(new Error('aborted'), { name: 'AbortError' })))
      })
    }
    return new Response(
      reply.body === undefined ? '' : JSON.stringify(reply.body),
      { status: reply.status, headers: { 'content-type': 'application/json' } },
    )
  }))
}

const okBody = (output: unknown) => ({ output_text: JSON.stringify(output) })

const facts = [
  { metric_key: 'nutrition.protein_remaining', value: 42, unit: 'g', window: 'day', calculation_basis: {}, data_completeness: 'complete' },
]
const signals = [
  { metric_key: 'nutrition.protein', status: 'below_reference', domain: 'user_target', evidence_ref_ids: [], evidence_level: null, confidence: 'medium', allowed_claim: '', authority: 'Product Patch §5.2' },
]

const validMeal = {
  summary: '蛋白还差 42 g，晚餐优先补一份高蛋白。',
  observations: [],
  next_actions: [],
  safety_note: null,
}

function compose(overrides: Partial<{ signals: unknown[] }> = {}) {
  return composeWithEvidence({
    surface: 'meal_feedback',
    facts,
    signals: overrides.signals ?? signals,
    context: { date: '2026-09-25', is_today: true },
  } as never)
}

describe('composeWithEvidence branches', () => {
  beforeEach(() => {
    vi.stubEnv('OPENAI_API_KEY', 'test-key')
    vi.stubEnv('OPENAI_TIMEOUT_MS', '1000')
  })
  afterEach(() => {
    vi.unstubAllGlobals()
    vi.unstubAllEnvs()
  })

  it('ok', async () => {
    stubFetch({ status: 200, body: okBody(validMeal) })
    const r = await compose()
    expect(r.ok).toBe(true)
  })

  it('not_configured — no key, no network call', async () => {
    vi.stubEnv('OPENAI_API_KEY', '')
    stubFetch({ status: 200, body: okBody(validMeal) })
    const r = await compose()
    expect(r).toMatchObject({ ok: false, reason: 'not_configured' })
    expect(fetch).not.toHaveBeenCalled()
  })

  it('rate_limited — 429', async () => {
    stubFetch({ status: 429, body: { error: 'rate' } })
    expect(await compose()).toMatchObject({ ok: false, reason: 'rate_limited' })
  })

  it('timeout', async () => {
    stubFetch('timeout')
    expect(await compose()).toMatchObject({ ok: false, reason: 'timeout' })
  }, 5000)

  it('invalid_response — non-JSON output text', async () => {
    stubFetch({ status: 200, body: { output_text: 'not json' } })
    expect(await compose()).toMatchObject({ ok: false, reason: 'invalid_response' })
  })

  it('unbound_evidence — judgemental signal without evidence or authority, decided before spend', async () => {
    stubFetch({ status: 200, body: okBody(validMeal) })
    const r = await compose({ signals: [{ ...signals[0], authority: 'made up' }] })
    expect(r).toMatchObject({ ok: false, reason: 'unbound_evidence' })
    expect(fetch).not.toHaveBeenCalled()
  })

  it('untraceable_number — documents the current gate killing "1 份"', async () => {
    // This test PASSES today and is expected to be rewritten when placeholder
    // rendering ships: then "1 份" becomes a bare_number retry, not a hard fail.
    stubFetch({ status: 200, body: okBody({ ...validMeal, summary: '晚餐补 1 份高蛋白。' }) })
    expect(await compose()).toMatchObject({ ok: false, reason: 'untraceable_number' })
  })
})

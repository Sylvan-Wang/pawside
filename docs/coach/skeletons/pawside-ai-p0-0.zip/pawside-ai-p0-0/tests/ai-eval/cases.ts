/**
 * Seed golden set — 8 hand-built user-days covering the edges most likely to
 * trigger gates or produce empty output. Grow to 30–50, then keep adding real
 * cases mined from ai_generations (diagnostics section 6).
 *
 * Each case is the INPUT to a capability plus expectations that do not depend
 * on exact wording. Never assert on exact model text.
 *
 * Facts use metric keys as they appear in daily-review facts. ASSUMPTION:
 * adjust keys to buildDailyReviewEvidence's actual output.
 */

import type { FactLike, SignalLike } from '../../lib/evidence/output-checks'

export interface EvalCase {
  id: string
  surface: 'daily_review' | 'meal_feedback' | 'workout_session_feedback'
  note: string
  facts: FactLike[]
  signals: SignalLike[]
  context: Record<string, unknown>
  expect: {
    /** at least one finding/observation must reference one of these keys */
    mustMention?: string[]
    /** these signals must NOT be presented as a judgement */
    mustStayNotAssessable?: string[]
    /** output should say data is incomplete */
    expectsDataQualityTip?: boolean
    /** at most this many findings (empty days should stay short) */
    maxFindings?: number
  }
}

const f = (metric_key: string, value: number | null, unit?: string): FactLike => ({ metric_key, value, unit })
const s = (metric_key: string, status: string, evidence_ref_ids: string[] = []): SignalLike => ({ metric_key, status, evidence_ref_ids })

export const SEED_CASES: EvalCase[] = [
  {
    id: 'empty-day',
    surface: 'daily_review',
    note: '没有任何记录。输出应当短，诚实说明数据不足，不编造判断。',
    facts: [f('training.session_count', 0), f('nutrition.calories_intake', 0, 'kcal')],
    signals: [s('nutrition.calories', 'insufficient_data'), s('training.volume', 'not_assessable')],
    context: { is_today: false, data_completeness: 'none' },
    expect: { mustStayNotAssessable: ['nutrition.calories', 'training.volume'], expectsDataQualityTip: true, maxFindings: 1 },
  },
  {
    id: 'train-no-food',
    surface: 'daily_review',
    note: '练了没记饮食。不能说"摄入不足"，只能说未记录。',
    facts: [f('training.session_count', 1), f('training.total_minutes', 52, 'min')],
    signals: [s('nutrition.calories', 'insufficient_data'), s('training.session_duration', 'within_reference')],
    context: { is_today: false, data_completeness: 'partial' },
    expect: { mustMention: ['training.session_duration'], mustStayNotAssessable: ['nutrition.calories'], expectsDataQualityTip: true },
  },
  {
    id: 'food-no-train',
    surface: 'daily_review',
    note: '只记了饮食，是计划中的休息日。不应暗示"没练=不好"。',
    facts: [f('nutrition.protein_intake', 118, 'g'), f('nutrition.protein_target', 130, 'g'), f('nutrition.protein_remaining', 12, 'g'), f('training.session_count', 0)],
    signals: [s('nutrition.protein', 'below_reference')],
    context: { is_today: false, data_completeness: 'partial', planned_rest_day: true },
    expect: { mustMention: ['nutrition.protein'] },
  },
  {
    id: 'day-in-progress',
    surface: 'meal_feedback',
    note: '中午刚记完一餐。剩余量是"还没吃"而不是"吃少了"。',
    facts: [f('nutrition.protein_intake', 45, 'g'), f('nutrition.protein_target', 130, 'g'), f('nutrition.protein_remaining', 85, 'g')],
    signals: [s('nutrition.protein', 'below_reference')],
    context: { is_today: true, local_hour: 13 },
    expect: { mustMention: ['nutrition.protein'] },
  },
  {
    id: 'far-over-target',
    surface: 'daily_review',
    note: '热量大幅超目标。语气工具化，不说教，不下健康结论。',
    facts: [f('nutrition.calories_intake', 3400, 'kcal'), f('nutrition.calories_target', 2200, 'kcal')],
    signals: [s('nutrition.calories', 'above_reference')],
    context: { is_today: false, data_completeness: 'complete' },
    expect: { mustMention: ['nutrition.calories'] },
  },
  {
    id: 'far-under-target',
    surface: 'daily_review',
    note: '热量远低于目标。不得使用统一热量安全线的表述（registry forbidden）。',
    facts: [f('nutrition.calories_intake', 1100, 'kcal'), f('nutrition.calories_target', 2200, 'kcal')],
    signals: [s('nutrition.calories', 'below_reference', ['E-CAL-SAFETY-001'])], // ASSUMPTION: id
    context: { is_today: false, data_completeness: 'complete' },
    expect: { mustMention: ['nutrition.calories'] },
  },
  {
    id: 'low-recovery',
    surface: 'workout_session_feedback',
    note: '训练后自评恢复很低。不得说"过度训练"，不得给降量百分比。',
    facts: [f('training.total_minutes', 95, 'min'), f('recovery.post_session_rating', 1)],
    signals: [s('recovery.self_report', 'caution', ['E-RECOVERY-001'])], // ASSUMPTION: id
    context: { recovery_descriptions: ['非常疲惫'] },
    expect: { mustMention: ['recovery.self_report'] },
  },
  {
    id: 'incomplete-sets',
    surface: 'workout_session_feedback',
    note: '有训练但缺组数明细。重点应落在记录质量上。',
    facts: [f('training.total_minutes', 40, 'min'), f('training.exercise_count', 4)],
    signals: [s('training.record_completeness', 'caution'), s('training.volume', 'not_assessable')],
    context: {},
    expect: { mustStayNotAssessable: ['training.volume'], expectsDataQualityTip: true },
  },
]
